const PAGE_SOURCE = 'tool-atelier-web';
const EXTENSION_SOURCE = 'tool-atelier-cors-extension';

function postResponse(requestId, response) {
  window.postMessage(
    {
      source: EXTENSION_SOURCE,
      requestId,
      response,
    },
    window.location.origin,
  );
}

/** 页面与扩展后台之间只传递带来源标记和请求 id 的消息。 */
window.addEventListener('message', (event) => {
  if (event.source !== window || event.data?.source !== PAGE_SOURCE) return;
  const { requestId, type, payload } = event.data;
  if (!requestId || !['PING', 'PROXY_REQUEST', 'CANCEL_REQUEST'].includes(type)) return;

  try {
    if (!chrome.runtime?.id) throw new Error('EXTENSION_CONTEXT_INVALIDATED');
    chrome.runtime.sendMessage(
      {
        type,
        requestId,
        ...(type === 'PROXY_REQUEST' ? { request: payload } : {}),
      },
      (response) => {
        try {
          const runtimeError = chrome.runtime.lastError?.message;
          postResponse(requestId, runtimeError ? { ok: false, error: runtimeError } : response);
        } catch {
          // 扩展重新加载后旧脚本上下文会失效，返回可恢复错误而不是抛出未处理异常。
          postResponse(requestId, {
            ok: false,
            error: '扩展已更新，请刷新当前页面后重试。',
          });
        }
      },
    );
  } catch {
    postResponse(requestId, {
      ok: false,
      error: '扩展已更新，请刷新当前页面后重试。',
    });
  }
});
