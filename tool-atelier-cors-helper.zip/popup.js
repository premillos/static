const enabledInput = document.querySelector('#enabled');
const statusText = document.querySelector('#status');

function renderStatus(enabled) {
  enabledInput.checked = enabled;
  statusText.textContent = enabled ? '代理已启用' : '代理已关闭';
}

chrome.runtime.sendMessage({ type: 'GET_STATUS' }, (response) => {
  renderStatus(response?.enabled !== false);
});

enabledInput.addEventListener('change', () => {
  enabledInput.disabled = true;
  chrome.runtime.sendMessage(
    { type: 'SET_ENABLED', enabled: enabledInput.checked },
    (response) => {
      enabledInput.disabled = false;
      renderStatus(response?.enabled !== false);
    },
  );
});
