const MAX_RESPONSE_BYTES = 5 * 1024 * 1024;
const MAX_REQUEST_FILE_BYTES = 10 * 1024 * 1024;
const MAX_TOTAL_REQUEST_FILE_BYTES = 30 * 1024 * 1024;
const activeRequests = new Map();

/** 仅接受工具工坊页面发来的消息，避免扩展被其他页面当作开放代理。 */
function isAllowedSender(sender) {
  const value = sender?.tab?.url || sender?.url || '';
  try {
    const url = new URL(value);
    if (
      url.protocol === 'http:' &&
      (url.hostname === '127.0.0.1' || url.hostname === 'localhost')
    ) {
      return true;
    }
    return url.origin === 'https://premillos.github.io' && url.pathname.startsWith('/static/');
  } catch {
    return false;
  }
}

function getRequestKey(sender, requestId) {
  return `${sender?.tab?.id ?? 'unknown'}:${requestId}`;
}

async function isEnabled() {
  const value = await chrome.storage.local.get({ enabled: true });
  return value.enabled !== false;
}

function sanitizeHeaders(items) {
  const forbidden = new Set([
    'connection',
    'content-length',
    'cookie',
    'host',
    'origin',
    'proxy-authorization',
    'referer',
  ]);
  const headers = new Headers();
  for (const [rawName, rawValue] of Array.isArray(items) ? items : []) {
    const name = String(rawName || '').trim();
    const lowerName = name.toLowerCase();
    if (!name || forbidden.has(lowerName) || lowerName.startsWith('sec-')) continue;
    headers.append(name, String(rawValue ?? ''));
  }
  return headers;
}

function collectHeaders(headers) {
  const result = {};
  headers.forEach((value, name) => {
    result[name.toLowerCase()] = value;
  });
  return result;
}

function validateTarget(input) {
  const url = new URL(String(input || ''));
  if (!['http:', 'https:'].includes(url.protocol)) throw new Error('仅支持 HTTP 或 HTTPS 地址');
  return url.toString();
}

function deserializeRequestFile(input) {
  if (!input || typeof input.data !== 'string') throw new Error('请选择要上传的文件');
  if (
    Number(input.size) > MAX_REQUEST_FILE_BYTES ||
    input.data.length > Math.ceil(MAX_REQUEST_FILE_BYTES / 3) * 4
  ) {
    throw new Error('上传文件不能超过 10 MB');
  }
  const binary = atob(input.data);
  if (binary.length > MAX_REQUEST_FILE_BYTES) throw new Error('上传文件不能超过 10 MB');
  const bytes = new Uint8Array(binary.length);
  for (let index = 0; index < binary.length; index += 1) bytes[index] = binary.charCodeAt(index);
  return new File([bytes], String(input.name || 'file'), {
    type: String(input.type || 'application/octet-stream'),
  });
}

function createRequestBody(request) {
  const inputs =
    Array.isArray(request.files) && request.files.length
      ? request.files
      : request.file
        ? [request.file]
        : [];
  if (
    inputs.reduce((total, item) => total + Number(item.size || 0), 0) > MAX_TOTAL_REQUEST_FILE_BYTES
  ) {
    throw new Error('上传文件总大小不能超过 30 MB');
  }
  if (request.bodyFormat === 'binary') return deserializeRequestFile(inputs[0]);
  if (request.bodyFormat !== 'multipart') return request.body;

  const formData = new FormData();
  new URLSearchParams(String(request.body || '')).forEach((value, name) => {
    formData.append(name, value);
  });
  for (const input of inputs) {
    const file = deserializeRequestFile(input);
    formData.append(String(input.fieldName || request.fileFieldName || 'file'), file, file.name);
  }
  return formData;
}

function bytesToBase64(bytes) {
  let binary = '';
  for (let offset = 0; offset < bytes.length; offset += 0x8000) {
    binary += String.fromCharCode(...bytes.subarray(offset, offset + 0x8000));
  }
  return btoa(binary);
}

async function readResponseBytes(response, method, maxResponseBytes) {
  if (method === 'HEAD') return new Uint8Array();
  const reader = response.body?.getReader?.();
  if (!reader) {
    const bytes = new Uint8Array(await response.arrayBuffer());
    if (bytes.byteLength > maxResponseBytes) throw new Error('响应超过设置上限，已停止读取');
    return bytes;
  }
  const chunks = [];
  let totalBytes = 0;
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    totalBytes += value.byteLength;
    if (totalBytes > maxResponseBytes) {
      await reader.cancel();
      throw new Error('响应超过设置上限，已停止读取');
    }
    chunks.push(value);
  }
  const bytes = new Uint8Array(totalBytes);
  let offset = 0;
  for (const chunk of chunks) {
    bytes.set(chunk, offset);
    offset += chunk.byteLength;
  }
  return bytes;
}

async function proxyRequest(message, sender) {
  if (!(await isEnabled())) throw new Error('扩展代理当前已关闭');
  const request = message.request || {};
  const method = String(request.method || 'GET').toUpperCase();
  const url = validateTarget(request.url);
  const timeoutMs = Math.min(120000, Math.max(100, Number(request.timeoutMs) || 10000));
  const settings = request.settings || {};
  const maxResponseBytes = Math.min(
    MAX_RESPONSE_BYTES,
    Math.max(1024, Number(settings.maxResponseBytes) || MAX_RESPONSE_BYTES),
  );
  const controller = new AbortController();
  const key = getRequestKey(sender, message.requestId);
  activeRequests.set(key, controller);
  const timer = setTimeout(() => controller.abort('timeout'), timeoutMs);
  const startedAt = Date.now();

  try {
    const options = {
      method,
      headers: sanitizeHeaders(request.headers),
      credentials: 'omit',
      redirect: settings.followRedirects === false ? 'manual' : 'follow',
      cache: ['default', 'no-store', 'reload', 'no-cache'].includes(settings.cache)
        ? settings.cache
        : 'no-store',
      signal: controller.signal,
    };
    if (!['GET', 'HEAD'].includes(method)) {
      const body = createRequestBody(request);
      if (body !== '') options.body = body;
    }
    const response = await fetch(url, options);
    const declaredLength = Number(response.headers.get('content-length') || 0);
    if (declaredLength > maxResponseBytes) throw new Error('响应超过设置上限，已停止读取');
    const bytes = await readResponseBytes(response, method, maxResponseBytes);
    return {
      ok: true,
      response: {
        ok: response.ok,
        status: response.status,
        statusText: response.statusText,
        durationMs: Math.max(0, Date.now() - startedAt),
        headers: collectHeaders(response.headers),
        finalUrl: response.url || url,
        redirected: response.redirected,
        // Fetch 不暴露中间跳转地址，至少保留起点和最终地址供页面核对。
        redirectChain: response.url && response.url !== url ? [url, response.url] : [url],
        bodyBase64: bytesToBase64(bytes),
      },
    };
  } catch (error) {
    const fallback =
      error?.name === 'AbortError' ? '请求已取消或超时' : error?.message || '扩展代理请求失败';
    return { ok: false, error: fallback };
  } finally {
    clearTimeout(timer);
    activeRequests.delete(key);
  }
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === 'GET_STATUS') {
    isEnabled().then((enabled) => sendResponse({ enabled }));
    return true;
  }
  if (message?.type === 'SET_ENABLED') {
    chrome.storage.local
      .set({ enabled: Boolean(message.enabled) })
      .then(() => sendResponse({ enabled: Boolean(message.enabled) }));
    return true;
  }
  if (!isAllowedSender(sender)) {
    sendResponse({ ok: false, error: '当前页面无权使用此扩展' });
    return false;
  }
  if (message?.type === 'PING') {
    isEnabled().then((enabled) =>
      sendResponse({
        ok: true,
        enabled,
        version: '1.5.2',
        capabilities: ['file-upload', 'multi-file-upload', 'binary-response', 'request-settings'],
      }),
    );
    return true;
  }
  if (message?.type === 'CANCEL_REQUEST') {
    activeRequests.get(getRequestKey(sender, message.requestId))?.abort('cancel');
    sendResponse({ ok: true });
    return false;
  }
  if (message?.type === 'PROXY_REQUEST') {
    proxyRequest(message, sender).then(sendResponse);
    return true;
  }
  return false;
});
